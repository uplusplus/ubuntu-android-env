#include <linux/errno.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/slab.h>
#include <linux/input.h>
#include <linux/init.h>
#include <linux/serio.h>
#include <linux/delay.h>
#include <linux/platform_device.h>
#include <linux/clk.h>
#include <asm/io.h>
#include <asm/irq.h>

#include <asm/plat-s3c24xx/ts.h>

#include <asm/arch/regs-adc.h>
#include <asm/arch/regs-gpio.h>

//s5pc110�����豸��������


//���¶��崥��ADת���Ĵ���
volatile unsigned long *tsadccon = NULL;
volatile unsigned long *tscon = NULL;
volatile unsigned long *tsdatx = NULL;
volatile unsigned long *tsdaty = NULL;

static struct input_dev *s5c_ts_dev;
static volatile struct s5c_ts_regs *s5c_ts_regs;

static void enter_wait_pen_down_mode(void)
{
		tscon = 0xd3;
}

static void enter_wait_pen_up_mode(void)
{
	  tscon = 0x1d3;
}

static void enter_measure_xy_mode(void)
{
		tscon = (1<<3)|(1<<2);
}

static void start_adc(void)
{
		tsadccon |= (1<<0);
}

static irqreturn_t pen_down_up_irq(int irq, void *dev_id)
{
	if (tsdatx & (1<<15))
	{
		printk("pen up\n");
		enter_wait_pen_down_mode();
	}
	else
	{
		//printk("pen down\n");
		//enter_wait_pen_up_mode();
		enter_measure_xy_mode();
		start_adc();
	}
	return IRQ_HANDLED;
}

static irqreturn_t adc_irq(int irq, void *dev_id)
{
	static int cnt = 0;
	printk("adc_irq cnt = %d, x = %d, y = %d\n", ++cnt, tsdatx & 0x3ff, tsdaty & 0x3ff);
	enter_wait_pen_up_mode();
	return IRQ_HANDLED;
}

static int s5c_ts_init(void)
{
	struct clk* clk;
	
	s5c_ts_dev = input_allocate_device();
	
	set_bit(EV_KEY, s5c_ts_dev->evbit);
	set_bit(EV_ABS, s5c_ts_dev->evbit);
	set_bit(BTN_TOUCH, s5c_ts_dev->keybit);
	
	input_set_abs_params(s5c_ts_dev, ABS_X, 0, 0x3FF, 0, 0);
	input_set_abs_params(s5c_ts_dev, ABS_Y, 0, 0x3FF, 0, 0);
	input_set_abs_params(s5c_ts_dev, ABS_PRESSURE, 0, 1, 0, 0);
	
	input_register_device(s5c_ts_dev);

	clk = clk_get(NULL, "adc");
	clk_enable(clk);
	
	
	tsadccon = (volatile unsigned long *)ioremap(0xe1700000,4);
	tscon 	 = (volatile unsigned long *)ioremap(0xe1700004,1);	
	tsdatx   = (volatile unsigned long *)ioremap(0xe170000c,4);
	tsdaty 	 = (volatile unsigned long *)ioremap(0xe1700010,4);	

	tsadccon = (1<<14)|(49<<6);

	request_irq(IRQ_TC, pen_down_up_irq, IRQF_SAMPLE_RANDOM, "ts_pen", NULL);
	request_irq(IRQ_ADC, adc_irq, IRQF_SAMPLE_RANDOM, "adc", NULL);

	enter_wait_pen_down_mode();
	
	return 0;
}

static void s5c_ts_exit(void)
{
	free_irq(IRQ_TC, NULL);
	iounmap(s5c_ts_regs);
	input_unregister_device(s5c_ts_dev);
	input_free_device(s5c_ts_dev);
}

module_init(s5c_ts_init);
module_exit(s5c_ts_exit);


MODULE_LICENSE("GPL");


