cat ./sd_fusing/c110.signedBL1_bin u-boot.bin > uboot.img
