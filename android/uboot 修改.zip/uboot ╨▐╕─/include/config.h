/* Automatically generated - do not edit */
#include <configs/smdkc110d_mtd.h>
