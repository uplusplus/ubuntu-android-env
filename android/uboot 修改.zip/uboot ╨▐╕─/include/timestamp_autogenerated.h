#define U_BOOT_DATE " 2월 16 2011"
#define U_BOOT_TIME "19:44:27"
